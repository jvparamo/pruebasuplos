-- Adminer 4.3.0 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `intelcost_bienes`;
CREATE DATABASE `intelcost_bienes` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `intelcost_bienes`;

DROP TABLE IF EXISTS `intelcost_bienes`;
CREATE TABLE `intelcost_bienes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` varchar(100) NOT NULL,
  `city_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `postal_code` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `city_id` (`city_id`),
  KEY `type_id` (`type_id`),
  CONSTRAINT `intelcost_bienes_ibfk_1` FOREIGN KEY (`city_id`) REFERENCES `intelcost_ciudades` (`id`),
  CONSTRAINT `intelcost_bienes_ibfk_2` FOREIGN KEY (`type_id`) REFERENCES `intelcost_tipos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `intelcost_ciudades`;
CREATE TABLE `intelcost_ciudades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `intelcost_tipos`;
CREATE TABLE `intelcost_tipos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2021-03-20 21:14:21
